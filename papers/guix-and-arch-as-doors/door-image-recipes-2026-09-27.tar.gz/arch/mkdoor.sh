#!/bin/sh
# mkdoor.sh -- build the Arch reader of the C4 door on an Arch host (or chroot) with archiso installed.
# Overlays profile/ onto archiso's releng (for boot-loader configs and the stock airootfs), renames the
# boot menus so the image never calls itself "Arch Linux", then runs mkarchiso.
# usage: sudo sh mkdoor.sh [WORKDIR] [OUTDIR]
# SPDX-License-Identifier: GPL-3.0-or-later
set -eu
here=$(cd "$(dirname "$0")" && pwd)
work=${1:-/tmp/c4door-work}; out=${2:-$here/out}
releng=/usr/share/archiso/configs/releng
[ -d "$releng" ] || { echo "mkdoor: $releng absent -- install archiso (pacman -S archiso)" >&2; exit 2; }
prof=$work/profile
rm -rf "$prof"; mkdir -p "$prof" "$out"
cp -r "$releng"/. "$prof"/
cp -r "$here"/profile/. "$prof"/
# Trademark: boot menus say what this is (based on Arch Linux), never that it is Arch Linux.
menus=$(find "$prof/syslinux" "$prof/efiboot" "$prof/grub" -type f \( -name '*.cfg' -o -name '*.conf' \))
for f in $menus; do sed -i 's/Arch Linux/C4 door (based on Arch Linux)/g' "$f"; done
if grep -n 'Arch Linux' $menus | grep -v 'based on Arch Linux'; then
  echo "mkdoor: a boot menu still names the image Arch Linux (above); refusing" >&2; exit 1
fi
mkarchiso -v -r -w "$work/build" -o "$out" "$prof"
ls -l "$out"; sha256sum "$out"/*.iso
