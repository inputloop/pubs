#!/usr/bin/env bash
# shellcheck disable=SC2034
# C4 door, based on Arch Linux. Derived from archiso configs/releng/profiledef.sh
# (gitlab.archlinux.org/archlinux/archiso, read 2026-09-27). Not Arch Linux; not endorsed by it.
# SPDX-License-Identifier: GPL-3.0-or-later

iso_name="c4door"
iso_label="C4DOOR_$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y%m)"
iso_publisher="C4 / ghostwheel collaborators (based on Arch Linux)"
iso_application="C4 door live system, based on Arch Linux"
iso_version="$(date --date="@${SOURCE_DATE_EPOCH:-$(date +%s)}" +%Y.%m.%d)"
install_dir="c4door"
buildmodes=('iso')
bootmodes=('bios.syslinux'
           'uefi.systemd-boot')
pacman_conf="pacman.conf"
airootfs_image_type="squashfs"
airootfs_image_tool_options=('-comp' 'xz' '-Xbcj' 'x86' '-b' '1M' '-Xdict-size' '1M')
file_permissions=(
  ["/etc/shadow"]="0:0:400"
  ["/root"]="0:0:750"
  ["/root/.automated_script.sh"]="0:0:755"
  ["/root/.gnupg"]="0:0:700"
  ["/usr/local/bin/choose-mirror"]="0:0:755"
  ["/usr/local/bin/Installation_guide"]="0:0:755"
  ["/usr/local/bin/livecd-sound"]="0:0:755"
  ["/etc/c4-door/"]="0:0:644"
)
