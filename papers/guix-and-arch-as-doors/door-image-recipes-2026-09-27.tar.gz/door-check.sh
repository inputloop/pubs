#!/bin/sh
# door-check.sh -- the door image's rules as checks that can fail.
# usage: sh door-check.sh [DIR]      (DIR defaults to this script's folder)
#        sh door-check.sh --prove-red  (plant each fault in a copy; every one must go RED,
#                                       the unplanted control must stay OK)
# Exit: 0 OK, 1 RED, 2 cannot run (no bash for profiledef.sh).
# SPDX-License-Identifier: GPL-3.0-or-later
set -u
here=$(cd "$(dirname "$0")" && pwd)
DVD_BYTES=4700372992   # single-layer DVD
DOORFILES="README WELCOME.org TERMS PRIVACY SOURCE"

check() {
  d=$1; red=0
  say() { echo "  $1"; }
  fail() { echo "  RED  $1"; red=1; }
  # A: the door is whole, and the Arch copy is the same bytes
  for f in $DOORFILES; do
    [ -s "$d/door/$f" ] || fail "A door/$f missing or empty"
    cmp -s "$d/door/$f" "$d/arch/profile/airootfs/etc/c4-door/$f" || fail "A arch airootfs copy of $f differs from door/$f"
  done
  # B: nothing from the lab or the machine in what a stranger reads first
  if grep -n -E '[A-Za-z]:\\|/f/claude|[Aa]valon|GIZA|gw[0-9]+\.bru\.st|mnt/(c4|pub)' "$d"/door/* >/dev/null 2>&1; then
    fail "B door names a machine, host or lab path: $(grep -l -E '[A-Za-z]:\\|/f/claude|[Aa]valon|GIZA|gw[0-9]+\.bru\.st|mnt/(c4|pub)' "$d"/door/* | tr '\n' ' ')"
  fi
  # C: the source duty is stated where a person will look
  grep -q 'section 6' "$d/door/SOURCE" 2>/dev/null || fail "C door/SOURCE does not state the GPLv3 section 6 duty"
  # D: the Guix reader
  scm=$d/guix/c4-door.scm
  grep -q '(inherit installation-os)' "$scm" 2>/dev/null || fail "D guix reader does not inherit installation-os"
  for f in $DOORFILES; do grep -q "\"$f\"" "$scm" 2>/dev/null || fail "D guix reader does not carry door/$f"; done
  lbl=C4_DOOR
  printf '%s' "$lbl" | grep -qE '^[A-Z0-9_]{1,32}$' || fail "D ISO label $lbl is not a legal volume id"
  # E: the Arch reader, read the way mkarchiso reads it (mkarchiso declares file_permissions -A first)
  command -v bash >/dev/null 2>&1 || { echo "  CANNOT  no bash to read profiledef.sh"; return 2; }
  pd=$d/arch/profile/profiledef.sh
  vals=$(bash -c 'declare -A file_permissions; . "$1"; printf "%s\n" "$iso_name" "$iso_label" "$iso_publisher" "$iso_application" "$install_dir"; printf "%s " "${bootmodes[@]}"' _ "$pd" 2>/dev/null) || fail "E profiledef.sh does not source"
  name=$(printf '%s\n' "$vals" | sed -n 1p); label=$(printf '%s\n' "$vals" | sed -n 2p)
  idir=$(printf '%s\n' "$vals" | sed -n 5p); modes=$(printf '%s\n' "$vals" | sed -n 6p)
  printf '%s\n' "$vals" | sed -n 1,4p | sed 's/based on Arch Linux//g' | grep -qi 'arch *linux\|^archlinux$' \
    && fail "E the image calls itself Arch Linux (trademark: say 'based on Arch Linux' only)"
  [ "$name" = archlinux ] && fail "E iso_name is archlinux"
  printf '%s' "$idir" | grep -qE '^[a-z0-9]{1,30}$' || fail "E install_dir '$idir' is not [a-z0-9], at most 30"
  [ ${#label} -le 32 ] || fail "E iso_label '$label' is longer than 32"
  for m in $modes; do case $m in bios.syslinux|uefi.grub|uefi.systemd-boot) ;; *) fail "E unknown bootmode $m";; esac; done
  [ -n "$modes" ] || fail "E no bootmodes"
  pk=$d/arch/profile/packages.x86_64
  for p in mkinitcpio mkinitcpio-archiso base linux; do grep -qx "$p" "$pk" 2>/dev/null || fail "E packages.x86_64 lacks $p"; done
  # F: the firmware fork is honoured (default A unless FIRMWARE-CHOICE says B)
  choice=A; [ -f "$d/arch/FIRMWARE-CHOICE" ] && choice=$(tr -dc 'AB' < "$d/arch/FIRMWARE-CHOICE" | cut -c1)
  if [ "$choice" = A ] && grep -qxF -f "$d/arch/FIRMWARE-DROPPED" "$pk" 2>/dev/null; then
    fail "F choice A but packages.x86_64 carries $(grep -xF -f "$d/arch/FIRMWARE-DROPPED" "$pk" | tr '\n' ' ')"
  fi
  # H: what the running system calls itself (hostname, first words on screen)
  [ "$(cat "$d/arch/profile/airootfs/etc/hostname" 2>/dev/null)" = c4door ] || fail "H Arch reader's hostname is not c4door"
  grep -q '^C4 door' "$d/arch/profile/airootfs/etc/motd" 2>/dev/null || fail "H Arch reader's motd does not open with the door"
  grep -q 'mkdoor: a boot menu still names' "$d/arch/mkdoor.sh" 2>/dev/null || fail "H mkdoor.sh lost its boot-menu naming guard"
  # G: every minted image fits the medium it is meant for
  if [ -f "$d/BUILDS.tsv" ]; then
    awk -F'\t' -v max=$DVD_BYTES '$1!~/^#/ && $4+0>max {print "  RED  G " $2 " is " $4 " bytes, over a DVD"; bad=1} END{exit bad}' "$d/BUILDS.tsv" || red=1
  fi
  return $red
}

prove_red() {
  t=$(mktemp -d); rc=0
  mk() { rm -rf "$t/$1"; mkdir -p "$t/$1"; cp -r "$here/door" "$here/guix" "$here/arch" "$t/$1"/; }
  expect() { # name want(OK|RED)
    if check "$t/$1" >"$t/$1.out" 2>&1; then got=OK; else got=RED; fi
    if [ "$got" = "$2" ]; then echo "ok    $1 -> $got"; else echo "WRONG $1 -> $got (wanted $2)"; cat "$t/$1.out"; rc=1; fi
  }
  mk control; expect control OK
  mk a-missing; rm "$t/a-missing/door/TERMS"; expect a-missing RED
  mk a-drift; echo x >> "$t/a-drift/arch/profile/airootfs/etc/c4-door/README"; expect a-drift RED
  mk b-leak; echo 'see F:\claude\c4' >> "$t/b-leak/door/README"; expect b-leak RED
  mk c-nosource; sed -i 's/section 6/sec. six/' "$t/c-nosource/door/SOURCE"; sed -i 's/section 6/sec. six/' "$t/c-nosource/arch/profile/airootfs/etc/c4-door/SOURCE"; expect c-nosource RED
  mk d-noinherit; sed -i 's/(inherit installation-os)//' "$t/d-noinherit/guix/c4-door.scm"; expect d-noinherit RED
  mk e-name; sed -i 's/^iso_name=.*/iso_name="archlinux"/' "$t/e-name/arch/profile/profiledef.sh"; expect e-name RED
  mk e-publisher; sed -i 's/^iso_publisher=.*/iso_publisher="Arch Linux door"/' "$t/e-publisher/arch/profile/profiledef.sh"; expect e-publisher RED
  mk e-idir; sed -i 's/^install_dir=.*/install_dir="C4-Door"/' "$t/e-idir/arch/profile/profiledef.sh"; expect e-idir RED
  mk e-boot; sed -i "s/'uefi.systemd-boot'/'uefi.lilo'/" "$t/e-boot/arch/profile/profiledef.sh"; expect e-boot RED
  mk e-initcpio; sed -i '/^mkinitcpio-archiso$/d' "$t/e-initcpio/arch/profile/packages.x86_64"; expect e-initcpio RED
  mk f-firmware; echo linux-firmware >> "$t/f-firmware/arch/profile/packages.x86_64"; expect f-firmware RED
  mk f-choiceB; echo linux-firmware >> "$t/f-choiceB/arch/profile/packages.x86_64"; echo B > "$t/f-choiceB/arch/FIRMWARE-CHOICE"; expect f-choiceB OK
  mk h-hostname; echo archiso > "$t/h-hostname/arch/profile/airootfs/etc/hostname"; expect h-hostname RED
  mk h-guard; sed -i '/mkdoor: a boot menu still names/d' "$t/h-guard/arch/mkdoor.sh"; expect h-guard RED
  mk g-toobig; printf 'guix\tc4door.iso\t-\t9000000000\n' > "$t/g-toobig/BUILDS.tsv"; expect g-toobig RED
  mk g-fits; printf 'guix\tc4door.iso\t-\t1300000000\n' > "$t/g-fits/BUILDS.tsv"; expect g-fits OK
  rm -rf "$t"; [ $rc = 0 ] && echo "PROVE-RED: every fault RED, every control OK" || echo "PROVE-RED: FAILED"
  return $rc
}

case ${1:-} in
  --prove-red) prove_red; exit $? ;;
  -h|--help) sed -n 2,7p "$0"; exit 0 ;;
esac
dir=${1:-$here}
echo "door-check $dir"
check "$dir"; r=$?
case $r in 0) echo "OK";; 2) echo "CANNOT"; exit 2;; *) echo "RED"; exit 1;; esac
