;;; c4-door.scm -- the C4 door on GNU Guix: Guix's own installer image,
;;; plus Emacs, Git, GnuPG and the door under /etc/c4-door/.
;;; Build (pinned, as minted 2026-09-27):
;;;   guix time-machine --commit=v1.5.0 -- system image --image-type=iso9660 --label=C4_DOOR c4-door.scm
;;; Unpinned, a 1.5.0 guix updates the channel to master and then looks for installer files at
;;; their newer path (gnu/installer/aux-files/logo.txt) and fails; the pin keeps the two in step.
;;; SPDX-License-Identifier: GPL-3.0-or-later

(use-modules (gnu)
             (gnu system install)
             (gnu services))
(use-package-modules emacs version-control gnupg)

(define %door-dir
  ;; The door files sit beside this recipe in ../door/.
  (string-append (dirname (current-filename)) "/../door"))

(define (door-file name)
  (list (string-append "c4-door/" name)
        (local-file (string-append %door-dir "/" name))))

(define %c4-door-service
  (simple-service 'c4-door etc-service-type
                  (map door-file
                       '("README" "WELCOME.org" "TERMS" "PRIVACY" "SOURCE"))))

(operating-system
  (inherit installation-os)
  (issue "C4 door -- a free system you can run from this stick.\nRead /etc/c4-door/README first.\n\n")
  (packages (append (list emacs-no-x git gnupg)
                    (operating-system-packages installation-os)))
  (services (cons %c4-door-service
                  (operating-system-user-services installation-os))))
